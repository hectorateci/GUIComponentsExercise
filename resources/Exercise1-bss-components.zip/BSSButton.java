package edu.eci.arsw.enterpriseguicomp.bss;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JButton;

public class BSSButton extends JButton {

	public BSSButton() {
		super();	
		this.setBackground(Color.GRAY);
	}

	public BSSButton(String arg0) {
		super(arg0);	
		this.setBackground(Color.GRAY);
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		g.setColor(Color.BLUE);
		
		int x2i=5;
		int y2i=this.getHeight();
		int x1i=0;
		int y1i=0;
		
		for (int i=0;i<10;i++){
			g.drawLine(x1i, y1i, x2i, y2i);
			x1i+=10;
			x2i+=10;
		}
		
	}

	
	
}
