package edu.eci.arsw.enterpriseguicomp.bss;

public class BSSSignatures {

	public String getCompanyName(){
		return "BSS Inc.";
	}
	
	public String getCompanyDescription(){
		return "BSS - the best company in the world.";
	}
	
	public String getContactEmail(){
		return "info@bss.org";
	}
	
	public String getPhone(){
		return "082309232";
	}
	
}
