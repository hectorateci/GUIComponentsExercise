package edu.eci.arsw.enterpriseguicomp.bss;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JTextArea;

public class BSSTextArea extends JTextArea {

	public BSSTextArea() {
		super();
		this.setBackground(Color.GRAY);
		// TODO Auto-generated constructor stub
	}

	public BSSTextArea(String arg0) {
		super(arg0);
		this.setBackground(Color.GRAY);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void paintComponent(Graphics g) {		
		super.paintComponent(g);
		
		int x2i=5;
		int y2i=this.getHeight();
		int x1i=0;
		int y1i=0;
		
		g.setColor(Color.BLUE);
		
		for (int i=0;i<100;i++){
			g.drawLine(x1i, y1i, x2i, y2i);
			x1i+=10;
			x2i+=10;
		}
	}

	
	
}
